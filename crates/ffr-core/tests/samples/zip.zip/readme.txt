Fast File Recovery sample archive.
